public class Main {
    public static void main(String[] args) {
        String file = "/Users/elinblomquist/Desktop/AlgoData/Graph/src/trains.csv";
    }
}