public class Connection {
    City city; //att åka till
    Integer distance;

    public Connection(City city, Integer distance) {
        this.city = city;
        this.distance = distance;
    }
}
